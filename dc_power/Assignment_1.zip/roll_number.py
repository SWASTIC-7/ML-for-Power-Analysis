#!/usr/bin/env python3
"""
DC Power Flow template for EET 109 – Autumn 2025
Roll No: <replace_with_your_rollno>

Note: Keep load_pglib_opf.py in the SAME folder as this script,
      then import as shown below. Do not rename or move it.
"""

## Do Not Change the above this. 

import time
import numpy as np
from load_pglib_opf import load_pglib_opf

def test(case_path):
    """
    Runs DCPF on the given PGLib case file.
    Returns:
      {
        "angles": [θ1, θ2, ...]    # float radians for each bus, in bus order,
        "time": <float>            # elapsed seconds (DCPF solve only)
      }
    """
    t0 = time.perf_counter()
    bus_df, gen_df, branch_df = load_pglib_opf(case_path)
    # Do not change the above line.


    # … STUDENT IMPLEMENTATION HERE …
    # Solve the DC Power Flow problem here.
    # voltage_angle must be a 1D numpy array or list, length = bus_df.shape[0]
    voltage_angle = [] 

    # Do not change the following line. Any edit below will result in Penalty.
    t1 = time.perf_counter()
    return {"angles": voltage_angle, "time": t1 - t0}

# == STANDING INSTRUCTION ==
if __name__ == "__main__":
    import sys, json
    case_file = sys.argv[1]
    result = test(case_file)
    sys.stdout.write(json.dumps(result))
